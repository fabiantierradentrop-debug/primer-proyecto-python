from django.contrib import admin
from .models import Actividad, PuntoDeJuego, PropuestaHogar

# =========================================================================
# === 1. REGISTRO DEL MODELO ACTVIDAD (Agenda Temporal) ===
# =========================================================================

@admin.register(Actividad)
class ActividadAdmin(admin.ModelAdmin):
    # Campos visibles en el listado del panel de administración
    list_display = (
        'nombre', 
        'fecha', 
        'zona', 
        'tipo_experiencia', 
        'tiempo_estimado_min', 
        'edad_min', 
        'link_reserva'
    )
    
    # Filtros laterales para curación rápida (agenda cultural)
    list_filter = ('zona', 'tipo_experiencia', 'fecha')
    
    # Campos de búsqueda rápida
    search_fields = ('nombre', 'descripcion')
    
    # Organización de los campos en la página de edición
    fieldsets = (
        ('Detalles de la Actividad', {
            'fields': ('nombre', 'descripcion', 'tipo_experiencia'),
        }),
        ('Logística', {
            'fields': ('fecha', 'zona', 'link_reserva'),
        }),
        ('Filtros de Edad y Tiempo', {
            'fields': ('edad_min', 'edad_max', 'tiempo_estimado_min'),
        }),
    )


# =========================================================================
# === 2. REGISTRO DEL MODELO PUNTO DE JUEGO (Monetización y Paternidad) ===
# =========================================================================

@admin.register(PuntoDeJuego)
class PuntoDeJuegoAdmin(admin.ModelAdmin):
    # Los dos campos más importantes de tu modelo de negocio deben estar visibles
    list_display = (
        'nombre', 
        'zona', 
        'categoria', 
        'frecuencia_paterna', # CLAVE: Indicador social/género
        'tier_suscripcion',   # CLAVE: Indicador de monetización
        'es_pago'
    )
    
    # Filtros laterales para la gestión comercial y social
    list_filter = ('tier_suscripcion', 'frecuencia_paterna', 'zona', 'es_pago', 'categoria')
    
    # Campos de búsqueda
    search_fields = ('nombre', 'direccion')

    # Organización de los campos para la edición
    fieldsets = (
        ('Información Básica', {
            'fields': ('nombre', 'direccion', 'zona', 'categoria', 'atracciones', 'es_pago'),
        }),
        ('Clasificación Social y Curación', {
            'fields': ('frecuencia_paterna',), 
            'description': 'Clasificación subjetiva de la presencia de padres varones en el lugar (Tu variable de género).'
        }),
        ('Monetización (Servicios Premium)', {
            'fields': ('tier_suscripcion', 'descripcion_detallada', 'url_fotos_videos', 'puede_recibir_comentarios'),
        }),
    )


# =========================================================================
# === 3. REGISTRO DEL MODELO PROPUESTA HOGAR (Foco de Desarrollo) ===
# =========================================================================

@admin.register(PropuestaHogar)
class PropuestaHogarAdmin(admin.ModelAdmin):
    # Priorizamos el bajo esfuerzo en la visualización (Tiempo de Preparación)
    list_display = (
        'nombre', 
        'tiempo_preparacion_min', 
        'tiempo_juego_est_min', 
        'edad_min', 
        'edad_max'
    )
    
    # Filtros para la curación pedagógica
    list_filter = ('tiempo_preparacion_min', 'tiempo_juego_est_min')
    
    # Campos de búsqueda
    search_fields = ('nombre', 'descripcion_pasos', 'materiales_requeridos')
    
    # Organización de los campos
    fieldsets = (
        ('Instrucciones y Vínculo', {
            'fields': ('nombre', 'descripcion_pasos', 'foco_desarrollo', 'link_inspiracion'),
        }),
        ('Logística (Bajo Esfuerzo)', {
            'fields': ('tiempo_preparacion_min', 'tiempo_juego_est_min', 'materiales_requeridos'),
        }),
        ('Filtros de Edad', {
            'fields': ('edad_min', 'edad_max'),
        }),
    )