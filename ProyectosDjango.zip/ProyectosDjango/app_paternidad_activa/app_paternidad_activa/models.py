from django.db import models
from django.core.validators import MinValueValidator

# =========================================================================
# === CONSTANTES DE CLASIFICACIÓN (Compartidas y Globales) ===
# =========================================================================

# Para modelos Actividad y PuntoDeJuego
ZONA_CHOICES = [
    ('GBAO', 'GBA Oeste (La Matanza, Morón, Ituzaingó)'),
    ('CABA', 'Ciudad Autónoma de Buenos Aires'),
    ('OTRO', 'Otras Zonas'),
]

# Choices para la Lógica de Monetización (PuntoDeJuego)
TIER_CHOICES = [
    ('F', 'FREE (Listado básico)'),
    ('S', 'SILVER (Contenido enriquecido, 3 fotos)'),
    ('G', 'GOLD (Destacado en búsquedas, fotos/videos ilimitados)'),
]

# Choices para la Lógica de Paternidad Activa (PuntoDeJuego) - Tu variable social clave
FRECUENCIA_CHOICES = [
    ('B', 'Baja (Mayormente madres/abuelas)'),
    ('M', 'Media (Mixto, presencia regular de padres)'),
    ('A', 'Alta (Espacio donde se nota la Paternidad Activa)'),
]

# Choices para el enfoque pedagógico (PropuestaHogar) - Tu variable de desarrollo
FOCO_CHOICES = [
    ('FINO', 'Motor Fino'),
    ('GRUE', 'Motor Grueso'),
    ('LENG', 'Lenguaje y Comunicación'),
    ('SENS', 'Sensorial'),
    ('VINC', 'Vínculo Emocional'),
    ('RES', 'Resolución de Problemas'),
]

# Choices para la Infraestructura de Juego (PuntoDeJuego)
ATRACCIONES_CHOICES = [
    ('PLB', 'Plaza Blanda'),
    ('TBG', 'Tobogán'),
    ('PLT', 'Pelotero'),
    ('PNT', 'Mural para Pintar'),
    ('CERR', 'Sector de juego cerrado/seguro'),
]


# =========================================================================
# === 1. MODELO PARA AGENDA CULTURAL TEMPORAL (Actividades con fecha) ===
# =========================================================================

class Actividad(models.Model):
    """Eventos culturales con fecha y hora específicas (ej. un taller, un recital)."""
    
    # Choices para la clasificación conceptual del evento
    TIPO_EXPERIENCIA_CHOICES = [
        ('SENS', 'Sensorial (Texturas, olores)'),
        ('MOTR', 'Motriz (Baile, Movimiento)'),
        ('VINC', 'Vincular (Juego compartido, Crianza)'),
        ('NARR', 'Narrativa (Cuentos, Teatro)'),
        ('MUSC', 'Musical (Recitales, Instrumentos)'),
        ('CIEN', 'Científica (Exploración, Naturaleza)'),
    ]

    nombre = models.CharField(max_length=150, verbose_name="Título de la Actividad")
    descripcion = models.TextField(verbose_name="Descripción y Requisitos")
    
    # Logística y Búsqueda (Optimizado con db_index)
    fecha = models.DateTimeField(verbose_name="Fecha y Hora de Inicio", db_index=True)
    zona = models.CharField(max_length=15, choices=ZONA_CHOICES, verbose_name="Zona", db_index=True)
    
    # Filtros de Primera Infancia
    edad_min = models.IntegerField(validators=[MinValueValidator(0)], verbose_name="Edad Mínima (meses o años)")
    edad_max = models.IntegerField(validators=[MinValueValidator(0)], verbose_name="Edad Máxima (meses o años)")
    tiempo_estimado_min = models.IntegerField(verbose_name="Duración Estimada (minutos)")
    
    # Clasificación de Valor 
    tipo_experiencia = models.CharField(
        max_length=4,
        choices=TIPO_EXPERIENCIA_CHOICES,
        default='NARR',
        verbose_name="Foco de la Experiencia"
    )
    
    link_reserva = models.URLField(verbose_name="Enlace Directo a Reserva", blank=True, null=True)

    class Meta:
        verbose_name = "Actividad Temporal"
        verbose_name_plural = "Actividades Temporales"
        ordering = ['fecha']

    def __str__(self):
        return f"{self.nombre} - {self.fecha.strftime('%Y-%m-%d')}"


# =========================================================================
# === 2. MODELO PARA PUNTOS DE JUEGO (Lugares Permanentes) ===
# =========================================================================

class PuntoDeJuego(models.Model):
    """Lugares permanentes con infraestructura de juego, sujetos a monetización."""

    # --- Monetización y Visibilidad ---
    tier_suscripcion = models.CharField(
        max_length=1,
        choices=TIER_CHOICES,
        default='F',
        verbose_name="Nivel de Suscripción",
        db_index=True # Clave para el ordenamiento en views.py
    )

    # --- Datos Básicos ---
    nombre = models.CharField(max_length=150, verbose_name="Nombre del Lugar")
    direccion = models.CharField(max_length=255)
    zona = models.CharField(max_length=15, choices=ZONA_CHOICES, verbose_name="Zona", db_index=True)
    categoria = models.CharField(max_length=50, verbose_name="Categoría (Bar, Plaza, Restó)")

    # --- Atributos de Juego y Cuidado ---
    atracciones = models.JSONField(
        default=list, 
        verbose_name="Infraestructura de Juego",
        help_text="Lista de códigos de ATRACCIONES_CHOICES presentes en el lugar."
    )
    es_pago = models.BooleanField(default=False, verbose_name="Es de acceso pago")
    
    # --- Variable de Género/Social (Tu Diferenciador) ---
    frecuencia_paterna = models.CharField(
        max_length=1,
        choices=FRECUENCIA_CHOICES,
        default='B',
        verbose_name="Frecuencia de Padres Varones",
        db_index=True # Clave para el filtrado social
    )

    # --- Contenido Premium (Tier Silver/Gold) ---
    descripcion_detallada = models.TextField(
        verbose_name="Descripción detallada para suscriptores",
        blank=True, null=True
    )
    url_fotos_videos = models.JSONField(
        default=list, 
        verbose_name="URLs de Fotos y Videos Premium",
        blank=True, null=True
    )
    puede_recibir_comentarios = models.BooleanField(
        default=False, 
        verbose_name="Permitir Reviews (Servicio Premium)"
    )

    class Meta:
        verbose_name = "Punto de Juego Permanente"
        verbose_name_plural = "Puntos de Juego Permanentes"
        
    def __str__(self):
        return self.nombre


# =========================================================================
# === 3. MODELO PARA PROPUESTAS EN EL HOGAR (Juegos de Vínculo) ===
# =========================================================================

class PropuestaHogar(models.Model):
    """Actividades para hacer en casa que fomentan el tiempo de calidad."""
    
    nombre = models.CharField(max_length=150, verbose_name="Nombre del Juego")
    descripcion_pasos = models.TextField(verbose_name="Instrucciones paso a paso")
    
    # Logística de bajo esfuerzo (clave para padres cansados)
    tiempo_preparacion_min = models.IntegerField(verbose_name="Tiempo de Preparación (min)", db_index=True)
    tiempo_juego_est_min = models.IntegerField(verbose_name="Tiempo de Juego Estimado (min)")
    
    # Filtros de Primera Infancia
    edad_min = models.IntegerField(validators=[MinValueValidator(0)], verbose_name="Edad Mínima (meses o años)")
    edad_max = models.IntegerField(validators=[MinValueValidator(0)], verbose_name="Edad Máxima (meses o años)")

    # Clasificación de Valor
    foco_desarrollo = models.JSONField(
        default=list, 
        verbose_name="Foco de Desarrollo",
        help_text="Lista de códigos de FOCO_CHOICES que desarrolla el juego."
    )
    
    materiales_requeridos = models.JSONField(
        default=list, 
        verbose_name="Materiales Requeridos",
        help_text="Lista de materiales simples (Ej: 'sábanas', 'cucharas')."
    )
    
    link_inspiracion = models.URLField(verbose_name="Link de Inspiración (Opcional)", blank=True, null=True)

    class Meta:
        verbose_name = "Propuesta para el Hogar"
        verbose_name_plural = "Propuestas para el Hogar"
        ordering = ['tiempo_preparacion_min'] # Orden por defecto: priorizar el bajo esfuerzo

    def __str__(self):
        return self.nombre