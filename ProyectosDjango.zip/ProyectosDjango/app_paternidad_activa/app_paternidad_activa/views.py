from django.shortcuts import render
from django.db.models import Case, When, Value, IntegerField
from django.utils import timezone 

# Importaciones de Modelos y Constantes (Asegúrate que estas constantes existan en models.py)
from .models import (
    Actividad, 
    PuntoDeJuego, TIER_CHOICES, FRECUENCIA_CHOICES, ATRACCIONES_CHOICES,
    PropuestaHogar, FOCO_CHOICES,
    ZONA_CHOICES # Importada del models.py
)

# =========================================================================
# === 1. FUNCIÓN PARA AGENDA CULTURAL TEMPORAL (Actividad) ===
# =========================================================================

def lista_actividades(request):
    """Filtra y lista eventos con fecha, priorizando lo más cercano en el tiempo."""
    
    # 1. Obtener filtros
    zona_filtrar = request.GET.get('zona')           
    experiencia_filtrar = request.GET.get('experiencia') 
    edad_hija = request.GET.get('edad')              
    fecha_filtrar = request.GET.get('fecha')
    
    # 2. Base del QuerySet: Eventos futuros
    actividades_query = Actividad.objects.filter(fecha__gte=timezone.now())

    # 3. Aplicar Filtros
    if zona_filtrar:
        actividades_query = actividades_query.filter(zona=zona_filtrar)
        
    if experiencia_filtrar:
        # Nota: Usamos 'tipo_experiencia' que es CharField
        actividades_query = actividades_query.filter(tipo_experiencia=experiencia_filtrar)
        
    if edad_hija and edad_hija.isdigit():
        edad_int = int(edad_hija)
        actividades_query = actividades_query.filter(
            edad_min__lte=edad_int,
            edad_max__gte=edad_int
        )
        
    if fecha_filtrar:
        actividades_query = actividades_query.filter(fecha__date=fecha_filtrar)

    # 4. Ordenamiento: Por fecha ascendente (lo más próximo primero)
    actividades_ordenadas = actividades_query.order_by('fecha')

    # 5. Contexto para la plantilla
    context = {
        'actividades': actividades_ordenadas,
        'zona_choices': ZONA_CHOICES,
        'experiencia_choices': Actividad.TIPO_EXPERIENCIA_CHOICES, 
    }

    return render(request, 'lista_actividades.html', context)


# =========================================================================
# === 2. FUNCIÓN PARA PUNTOS DE JUEGO (Monetización y Paternidad) ===
# =========================================================================

def lista_puntos_de_juego(request):
    """Filtra y lista lugares permanentes, priorizando por Nivel de Suscripción (GOLD > SILVER > FREE)."""
    
    # 1. Obtener filtros
    zona_filtrar = request.GET.get('zona')          
    atraccion_filtrar = request.GET.get('atraccion') 
    frecuencia_filtrar = request.GET.get('frecuencia') 

    # 2. Base del QuerySet
    puntos_query = PuntoDeJuego.objects.all()

    # 3. Aplicar Filtros
    if zona_filtrar:
        puntos_query = puntos_query.filter(zona=zona_filtrar)
    
    if atraccion_filtrar:
        # Filtrado en el campo JSONField
        puntos_query = puntos_query.filter(atracciones__contains=[atraccion_filtrar]) 
        
    if frecuencia_filtrar:
        # Filtrado por la variable de género/social
        puntos_query = puntos_query.filter(frecuencia_paterna=frecuencia_filtrar)

    # 4. Lógica de Ordenamiento por Monetización (CRUCIAL)
    puntos_ordenados = puntos_query.annotate(
        # Asignamos valores numéricos para forzar el orden: G=3, S=2, F=1
        orden_tier=Case(
            When(tier_suscripcion='G', then=Value(3)), 
            When(tier_suscripcion='S', then=Value(2)), 
            When(tier_suscripcion='F', then=Value(1)), 
            default=Value(0),
            output_field=IntegerField()
        )
    # Ordena primero por Tier (descendente) y luego por nombre.
    ).order_by('-orden_tier', 'nombre') 

    # 5. Contexto para la plantilla
    context = {
        'puntos': puntos_ordenados,
        'atracciones_choices': ATRACCIONES_CHOICES,
        'frecuencia_choices': FRECUENCIA_CHOICES,
        'zona_choices': ZONA_CHOICES,
    }

    return render(request, 'puntos_de_juego.html', context)


# =========================================================================
# === 3. FUNCIÓN PARA PROPUESTAS EN EL HOGAR (Vínculo y Bajo Esfuerzo) ===
# =========================================================================

def lista_propuestas_hogar(request):
    """Filtra y lista actividades en casa, priorizando por bajo tiempo de preparación."""
    
    # 1. Obtener filtros
    foco_filtrar = request.GET.get('foco')          
    max_tiempo_prep = request.GET.get('max_prep')   
    edad_hija = request.GET.get('edad')             

    # 2. Base del QuerySet
    propuestas_query = PropuestaHogar.objects.all()

    # 3. Aplicar Filtros
    
    # Filtro por Foco de Desarrollo (filtrando dentro de la lista JSONField)
    if foco_filtrar:
        propuestas_query = propuestas_query.filter(foco_desarrollo__contains=[foco_filtrar])
        
    # Filtro por Tiempo de Preparación (CLAVE: Paternidad Activa)
    if max_tiempo_prep and max_tiempo_prep.isdigit():
        propuestas_query = propuestas_query.filter(tiempo_preparacion_min__lte=int(max_tiempo_prep)) 
        
    # Filtro por Edad
    if edad_hija and edad_hija.isdigit():
        edad_int = int(edad_hija)
        propuestas_query = propuestas_query.filter(
            edad_min__lte=edad_int,
            edad_max__gte=edad_int
        )

    # 4. Ordenamiento: Por tiempo de preparación ascendente (priorizando el menor esfuerzo)
    propuestas_ordenadas = propuestas_query.order_by('tiempo_preparacion_min', 'nombre') 

    # 5. Contexto para la plantilla
    context = {
        'propuestas': propuestas_ordenadas,
        'foco_choices': FOCO_CHOICES, 
    }

    return render(request, 'propuestas_hogar.html', context)