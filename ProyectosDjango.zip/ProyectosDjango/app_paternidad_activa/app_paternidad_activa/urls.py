from django.contrib import admin
from django.urls import path
from app_paternidad_activa import views

urlpatterns = [
    path('admin/', admin.site.urls),

    # Página principal
    path('', views.lista_actividades, name='home'),

    # Secciones
    path('agenda-cultural/', views.lista_actividades, name='actividades'),
    path('puntos-de-juego/', views.lista_puntos_de_juego, name='puntos'),
    path('juegos-en-casa/', views.lista_propuestas_hogar, name='hogar'),
]
